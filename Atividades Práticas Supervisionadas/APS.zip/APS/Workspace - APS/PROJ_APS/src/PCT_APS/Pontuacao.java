package PCT_APS;

import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.Toolkit;
import java.awt.Window.Type;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;


public class Pontuacao extends Menu {


	private JPanel contentPane;

	public Pontuacao() {
		setType(Type.UTILITY);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Pontuacao.class.getResource("/PCT_APS/Logos/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 522, 246);
		//JTextPane txtpnNvelFcil = new JTextPane();
		//txtpnNvelFcil.setEditable(false);
		//txtpnNvelFcil.setBackground(new Color(0, 128, 0));
		//txtpnNvelFcil.setFont(new Font("Segoe UI", Font.BOLD, 18));
		//txtpnNvelFcil.setText("\u2022 N\u00EDvel F\u00E1cil: M\u00EDnimo de 13 pontos para ganhar.\r\n\r\n\u2022 N\u00EDvel M\u00E9dio: M\u00EDnimo de 18 pontos para ganhar.\r\n\r\n\u2022 N\u00EDvel Dif\u00EDcil: M\u00EDnimo de 23 pontos para ganhar.");
		contentPane = new JPanel();
		contentPane.setBackground(new Color(154, 205, 50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JTextPane txtpnNvelFcil = new JTextPane();
		txtpnNvelFcil.setEditable(false);
		txtpnNvelFcil.setBackground(new Color(154, 205, 50));
		txtpnNvelFcil.setFont(new Font("Segoe UI", Font.BOLD, 18));
		txtpnNvelFcil.setText("\u2022 N\u00EDvel F\u00E1cil: M\u00EDnimo de 13 pontos para ganhar.\r\n\r\n\u2022 N\u00EDvel M\u00E9dio: M\u00EDnimo de 18 pontos para ganhar.\r\n\r\n\u2022 N\u00EDvel Dif\u00EDcil: M\u00EDnimo de 23 pontos para ganhar.");
		
		JButton btnOk = new JButton("OK!");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
			
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtpnNvelFcil, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(404, Short.MAX_VALUE)
					.addComponent(btnOk)
					.addGap(45))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(txtpnNvelFcil, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
					.addComponent(btnOk)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}

}
